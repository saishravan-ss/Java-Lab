package com.shravan.demo;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mycompany.app.Asci;

@RestController
public class ServiceController{
	
	@RequestMapping("/Asci")
	
}
